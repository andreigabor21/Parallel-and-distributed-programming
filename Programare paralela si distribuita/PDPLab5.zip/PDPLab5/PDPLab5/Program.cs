﻿#region Using

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

#endregion

namespace PDPLab5
{
    public sealed class Downloader
    {
        private readonly WebClient _client = new WebClient();

        public async Task DoSingleJobAsync(string url)
        {
            Console.WriteLine($"Started job: {url}");
            await _client.DownloadFileTaskAsync(url, Guid.NewGuid() + ".jpg");
            Console.WriteLine($"Finished job: {url}");
        }

        public static async Task DoAllJobsAsync(params string[] urls)
        {
            await Task.WhenAll(from url in urls select new Downloader().DoSingleJobAsync(url));
        }
    }

    public static class Program
    {
        public static void Main()
        {
            string[] distinctFiles =
            {
                "https://orig00.deviantart.net/02d9/f/2009/357/6/8/shortest_day_sunrise_by_ccplusplus.jpg",
                "https://orig00.deviantart.net/f135/f/2010/099/0/a/tranquility_by_ccplusplus.jpg",
                "https://orig00.deviantart.net/77ea/f/2010/188/0/e/stop__watch__wonder____by_ccplusplus.jpg"
            };

            var allFiles = new List<string>();
            for (var rep = 1; rep <= 10; ++rep)
                allFiles.AddRange(distinctFiles);

            Downloader.DoAllJobsAsync(allFiles.ToArray()).GetAwaiter().GetResult();
        }
    }
}