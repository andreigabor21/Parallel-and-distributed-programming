﻿#region Using

using System;
using System.Threading;
using System.Threading.Tasks;

#endregion

namespace PDPLab8
{
    public static class StaticRandom
    {
        private static int _seed = Environment.TickCount;

        private static readonly ThreadLocal<Random> R =
            new ThreadLocal<Random>(() => new Random(Interlocked.Increment(ref _seed)));

        public static int Next()
        {
            return R.Value.Next();
        }

        public static int Next(int minValue, int maxValue)
        {
            return R.Value.Next(minValue, maxValue);
        }

        public static int Next(int maxValue)
        {
            return R.Value.Next(maxValue);
        }

        public static void Shuffle<T>(T[] vector)
        {
            for (var i = 0; i < vector.Length; ++i)
            {
                var j = Next(i, vector.Length);

                var aux = vector[j];
                vector[j] = vector[i];
                vector[i] = aux;
            }
        }

        public static int[] Permute(int length)
        {
            var perm = new int[length];
            for (var i = 0; i < length; ++i)
                perm[i] = i;

            Shuffle(perm);

            return perm;
        }
    }

    public sealed class DirectedGraph
    {
        private readonly int _vertexCount;
        private readonly bool[,] _adjacencyMatrix;

        public DirectedGraph(int vertexCount, int edgeCount)
        {
            if (vertexCount < 2)
                throw new InvalidOperationException("Invalid vertex count!");

            _vertexCount = vertexCount;
            _adjacencyMatrix = new bool[vertexCount, vertexCount];

            if (edgeCount < 0 || edgeCount > vertexCount * (vertexCount - 1))
                throw new InvalidOperationException("Invalid edge count!");

            while (edgeCount > 0)
            {
                var start = StaticRandom.Next(vertexCount);
                var end = StaticRandom.Next(vertexCount);

                if (start != end && !_adjacencyMatrix[start, end])
                {
                    _adjacencyMatrix[start, end] = true;
                    edgeCount--;
                }
            }
        }

        public bool IsHamiltonianCycle(int[] path)
        {
            if (path.Length != _vertexCount)
                throw new InvalidOperationException("Path must be complete!");

            for (var i = 0; i < _vertexCount - 1; ++i)
                if (!_adjacencyMatrix[path[i], path[i + 1]])
                    return false;

            return _adjacencyMatrix[path[_vertexCount - 1], 0];
        }
    }

    public static class Program
    {
        public static void Main(string[] args)
        {
            const int vertexCount = 100;
            const int edgeCount = 9000;
            var dg = new DirectedGraph(vertexCount, edgeCount);
            Console.WriteLine("Generated directed graph...");

            const int workerCount = 10;
            const int iterationCount = 1000000;
            var workers = new Task[workerCount];

            for (var crt = 0; crt < workerCount; ++crt)
                workers[crt] = Task.Factory.StartNew(() =>
                {
                    for (var i = 0; i < iterationCount; ++i)
                    {
                        var path = StaticRandom.Permute(vertexCount);
                        if (dg.IsHamiltonianCycle(path))
                        {
                            Console.WriteLine(string.Join(",", path));
                            break;
                        }
                    }
                });

            Task.WaitAny(workers);
        }
    }
}