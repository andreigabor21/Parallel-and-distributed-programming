﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Cloo;
using System.Text;
using System.Windows.Forms;

namespace CLAtomics
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //No initialization needed
            //Cloo auto initializes

            //Creates a context only for the GPU
            //If you are running OpenCL using only a CPU, you will need to change this
            ComputeContextPropertyList Properties = new ComputeContextPropertyList(ComputePlatform.Platforms[0]);
            Context = new ComputeContext(ComputeDeviceTypes.Gpu, Properties, null, IntPtr.Zero);
            //Create the command queue
            CQ = new ComputeCommandQueue(Context, Context.Devices[0], ComputeCommandQueueFlags.None);


            //Using OpenCL 1.1, it will no longer be necessary to enable int32 atomics, they have become built-in
            #region Kernel OpenCL 99 Source code
            string atomicsKernels = @"
#pragma OPENCL EXTENSION cl_khr_global_int32_base_atomics : enable
#pragma OPENCL EXTENSION cl_khr_local_int32_base_atomics : enable
#pragma OPENCL EXTENSION cl_khr_global_int32_extended_atomics : enable
#pragma OPENCL EXTENSION cl_khr_local_int32_extended_atomics : enable

void GetSemaphor(__global int * semaphor)
{
  int occupied = atom_xchg(semaphor, 1);
  while(occupied > 0)
  {
      occupied = atom_xchg(semaphor, 1);
  }
}

void ReleaseSemaphor(__global int * semaphor)
{
   int prevVal = atom_xchg(semaphor, 0);
}

 __kernel void
kernelAtomInc(__global int * num)
{
    atom_inc(&num[0]);
}

__kernel void
kernelNoAtomInc(__global int * num,
                __global int * semaphor)
{
    int i = get_global_id(0);
    GetSemaphor(&semaphor[0]);
    {
       num[0]++;
    }
    ReleaseSemaphor(&semaphor[0]);
}

__kernel void maxAtomics(__global int * list,
                         __global int * maxNum)

{
  int i = get_global_id(0);
  int prevMax = atom_max(&maxNum[0],list[i]);
}

__kernel void maxNoAtomics(__global int * list,
                           __global int * maxNum,
                           __global int * semaphor)
{
  int i = get_global_id(0);
  GetSemaphor(&semaphor[0]);
  {
    int localMax = max(maxNum[0], list[i]);
    maxNum[0] = localMax; 
  }
  ReleaseSemaphor(&semaphor[0]);
}


";
            #endregion

            //Create a new OpenCL program
            ComputeProgram prog = null;

            try
            {
                prog = new ComputeProgram(Context, atomicsKernels);

                //I had to do this because I have a Radeon 5770 that supports atomics and a 4890 that doesn't. 
                //So only my device[0] will actually compile.
                List<ComputeDevice> dev = new List<ComputeDevice>() { Context.Devices[0] };

                //Builds the program for the devices
                prog.Build(dev, "", null, IntPtr.Zero);

            }
            catch
            {
                MessageBox.Show("Program build error");
            }

            //Create buffers
            CLnumAtom = new ComputeBuffer<int>(Context, ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer, new int[1]);
            CLnumNoAtom = new ComputeBuffer<int>(Context, ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer, new int[1]);
            CLSemaphor = new ComputeBuffer<int>(Context, ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer, new int[1]);



            //Create the kernels
            kernelAtomInc = prog.CreateKernel("kernelAtomInc");
            kernelNoAtomInc = prog.CreateKernel("kernelNoAtomInc");
            kernelAtomMax = prog.CreateKernel("maxAtomics");
            kernelmaxNoAtomics = prog.CreateKernel("maxNoAtomics");

            //Kernel arguments
            kernelAtomInc.SetMemoryArgument(0, CLnumAtom);
            kernelNoAtomInc.SetMemoryArgument(0, CLnumNoAtom);
            kernelNoAtomInc.SetMemoryArgument(1, CLSemaphor);




        }

        #region Contexts, command queue, variables, kernels
        ComputeContext Context;
        //Create the command queue
        ComputeCommandQueue CQ;

        ComputeBuffer<int> CLnumAtom;
        ComputeBuffer<int> CLnumNoAtom;
        ComputeBuffer<int> CLSemaphor;

        ComputeKernel kernelAtomInc;
        ComputeKernel kernelNoAtomInc;

        ComputeKernel kernelAtomMax;
        ComputeKernel kernelmaxNoAtomics;
        #endregion
        private void btnAtomicTest_Click(object sender, EventArgs e)
        {
            lstAns.Items.Clear();

            int N = (int)num.Value;


            #region Atomic increment test
            CQ.Write<int>(CLnumAtom, new int[1], null);
            CQ.Write<int>(CLnumNoAtom, new int[1], null);

            CQ.Execute(kernelAtomInc, null, new long[1] { N }, new long[1] { 1 }, null);
            CQ.Execute(kernelNoAtomInc, null, new long[1] { N }, new long[1] { 1 }, null);

            int[] numAtom = CQ.Read<int>(CLnumAtom, null);
            int[] numNoAtom = CQ.Read<int>(CLnumNoAtom, null);

            lstAns.Items.Add("Number of items is " + N.ToString());
            lstAns.Items.Add("****************************************");
            lstAns.Items.Add("Increment test - Expected result is " + N.ToString());
            lstAns.Items.Add("Atomics: "+numAtom[0].ToString());
            lstAns.Items.Add("No atomics: "+numNoAtom[0].ToString());
            lstAns.Items.Add("****************************************");

            int[] semaphorVal = CQ.Read<int>(CLSemaphor, null);
            #endregion

            #region Atomic maximum test
            int[] numbers = new int[N];
            for (int i = 0; i < N; i++) numbers[i] = i+1;

            //Shuffle numbers
            Random rnd = new Random();
            int temp; int ind0; int ind1;
            for (int i=0;i<N;i++)
            {
                ind0 = rnd.Next(0, N);
                ind1 = rnd.Next(0, N);
                temp = numbers[ind0];
                numbers[ind0] = numbers[ind1];
                numbers[ind1] = temp;
            }

            CQ.Write<int>(CLnumAtom, new int[1], null);
            CQ.Write<int>(CLnumNoAtom, new int[1], null);
            ComputeBuffer<int> CLList = new ComputeBuffer<int>(Context, ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer, numbers);

            kernelAtomMax.SetMemoryArgument(0, CLList); kernelmaxNoAtomics.SetMemoryArgument(0, CLList);
            kernelAtomMax.SetMemoryArgument(1, CLnumAtom); kernelmaxNoAtomics.SetMemoryArgument(1, CLnumNoAtom);
            kernelmaxNoAtomics.SetMemoryArgument(2, CLSemaphor);

            CQ.Execute(kernelAtomMax, null, new long[1] { N }, new long[1] { 1 }, null);
            CQ.Execute(kernelmaxNoAtomics, null, new long[1] { N }, new long[1] { 1 }, null);

            numAtom = CQ.Read<int>(CLnumAtom, null);
            numNoAtom = CQ.Read<int>(CLnumNoAtom, null);

            lstAns.Items.Add("Read maximum test - Expected result is " + N.ToString());
            lstAns.Items.Add("Atomics: " + numAtom[0].ToString());
            lstAns.Items.Add("No atomics: " + numNoAtom[0].ToString());
            lstAns.Items.Add("****************************************");
            #endregion
        }
    }
}
